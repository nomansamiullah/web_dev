<?php
session_start();

if($_SESSION['userlogin']=="")
header("location:login.php");


echo "<h1> Welcome ".$_SESSION['userlogin']."</h1>";

?>
<a href="logout.php">Log out</a>