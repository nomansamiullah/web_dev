<?php

$a = 10;
$b = 10.00;




if($a===$b)
echo "a and b are equal";
else
echo "a and b are not equal";

($a<=10) ? "yes a is less than 10" : "Sorry a is not less than 10"

?>

