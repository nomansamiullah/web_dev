<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First Page| Insert Data</title>
</head>
<body>
    <form name="frmadd" action="insertcode.php" method="post" enctype="multpart/Form-data">
<table border="1" width="50%" align="text-center">
    <tr><td colspan="2"><h2>Insert Data Form</h2></td></tr>
    <tr><td> Name:</td><td> <input type="text" id="txtname" name="txtname" required></td>
    </tr>
    <tr><td> Email:</td><td> <input type="email" id="txtemail1" name="txtemail1" required></td>
    </tr>
    <tr><td> Password:</td><td> <input type="password" id="txtpassword1" name="txtpassword1" required></td>
    </tr>
     <tr><td> Gender:</td><td> Male:<input type="radio" id="rdgender" name="rdgender"  value="Male"> 
                               Female:<input type="radio" id="rdgender" name="rdgender"  value="Female">
                          </td>
    </tr>
    <tr><td colspan="2" align="center"> <input type="submit" id="btnadd" name="btnadd" value="Add Data"></td>
    </tr>
</table>
</form>
</body>
</html>