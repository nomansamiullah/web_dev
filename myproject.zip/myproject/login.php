<?php
session_start();
include("connection.php");

if(isset($_POST['btnlogin']))
{

$useremail  =   $_POST['txtemail1'];
$userpswrd  =   $_POST['txtpassword1'];

$query      =   "select * from tblstudent where stdemail = '$useremail' and stdpassword= '$userpswrd'"; 

$result = $mysqli -> query($query);

if(mysqli_num_rows($result)>0)
{

$row    =   mysqli_fetch_array($result);
$_SESSION['userlogin']= $row['stdname'];
header("location:viewdata.php");

}else
{
    echo $error  =   "Invallid User name or password";
}

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First Page| Insert Data</title>
</head>
<body>
    <form name="frmadd"  method="post" enctype="multpart/Form-data">
<table border="1" width="50%" align="text-center">
    <tr><td colspan="2"><h2>Login Form</h2></td></tr>
    
    <tr><td> Email:</td><td> <input type="email" id="txtemail1" name="txtemail1" required></td>
    </tr>
    <tr><td> Password:</td><td> <input type="password" id="txtpassword1" name="txtpassword1" required></td>
    </tr>
    
    <tr><td colspan="2" align="center"> <input type="submit" id="btnlogin" name="btnlogin" value="Login..."></td>
    </tr>
</table>
</form>
</body>
</html>