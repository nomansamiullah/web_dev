<?php
include("connection.php");

$name 		=	$_POST['txtname'];
$email 		=	$_POST['txtemail1'];
$pswrd 		=	$_POST['txtpassword1'];
$gender 	=	$_POST['rdgender'];

$query 		=	"insert into tblstudent(stdname,stdemail,stdpassword,stdgender) values ('$name','$email','$pswrd','$gender')";
if ($result = $mysqli -> query($query)) {
	echo "Your Data has been inserted";
  
}else
{
	echo "Sorry but data has not been inserted";
}

?>